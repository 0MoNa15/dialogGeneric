package com.example.dialoggeneric.Util.Internet.Model

class ConnectionModel(var conectionStatus : Boolean) {
}
package com.mona15.dialog

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import android.arch.lifecycle.Observer
import android.support.v7.app.AppCompatActivity
import com.example.dialoggeneric.Util.Internet.Model.ConnectionModel
import com.example.dialoggeneric.Util.Internet.ValidInternetConnection

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ValidInternetConnection(this).observe(this,
            Observer<ConnectionModel>{
                if (it!!.conectionStatus){
                    Log.e("Internet", "VERDADERO NO HAY")
                    Toast.makeText(this, "VERDADERO", Toast.LENGTH_SHORT)
                } else {
                    Log.e("Internet", "FALSO SI HAY")
                    Toast.makeText(this, "FALSO", Toast.LENGTH_SHORT)
                }
            }
        )

    }
}

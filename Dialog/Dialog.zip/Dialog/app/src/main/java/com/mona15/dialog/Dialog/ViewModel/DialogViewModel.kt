package com.example.dialoggeneric.Dialog.ViewModel

import android.arch.lifecycle.ViewModel

class DialogViewModel : ViewModel(){

}
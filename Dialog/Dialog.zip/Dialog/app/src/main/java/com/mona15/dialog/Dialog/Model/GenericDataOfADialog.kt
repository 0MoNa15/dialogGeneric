package com.example.dialoggeneric.Dialog.Model

import android.databinding.BaseObservable
import android.graphics.drawable.Drawable
import com.example.dialoggeneric.Util.ValidateData

/**
 * Modelo encargado de gestionar los datos a utilizar en un diálogo
 * y validar la lógica de negocio que se necesita
 */
class GenericDataOfADialog() : BaseObservable() {

    var mValidateData: ValidateData = ValidateData()
    var mAvailable: Boolean = false
    var mIcon: Drawable? = null
    var mTitle: String = ""
        set(title) {
            if (mValidateData.validateTextNotNull(title) && mValidateData.validateTextNotEmpty(title)){
                field = title
            }
        }




}